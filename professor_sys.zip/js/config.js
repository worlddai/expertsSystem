﻿window.gConfig = {
    host:"http://localhost:9200"
}