
# author daiyujie
# email  Mail_163dai@163.com
# 专家系统   host/
# 专家抽取   host/sample
# 配置host以及最大数量   js/config.js
# 配置单位级联数据、专业领域级联数据、级联数据名称   config/*.json

