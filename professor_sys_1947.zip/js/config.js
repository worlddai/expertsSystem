﻿window.gConfig = {
    host: "http://localhost:9200",
    max_data_size: 1000 //--设置最大专家数量级。不能超过10000
}